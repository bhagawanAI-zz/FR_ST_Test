def create_template_multiple_images_single_face(image_tuple):
    DEBUG = False
    # # input is is this structure
    # (
    #     TemplateRole->int, enroll/verify
    #     (
    #         #1st image details
    #             (label->int, width->int, height->int, depth->int),
    #             (long-data-1D-list->[int])
    #         ),
    #         ...
    #         ...
    #         ...
    #         (#Nth face details
    #             (label->int, width->int, height->int, depth->int),
    #             (long-data-1D-list->[int])
    #         )
    #     )
    # )
    if DEBUG:
        print('create_template_multiple_images_single_face => input info ...')
        print("PYTHON: 1 : ", type(image_tuple)) # tuple 
        print("PYTHON: 2 : ", len(image_tuple))  # of length 2
        print("PYTHON: 3 : ", type(image_tuple[0])) # integer
        print("PYTHON: 3.1 : ", image_tuple[0])  # having tempalte role 0/1/2/3 -> we use 0 and 1 only
        print("PYTHON: 4 : ", type(image_tuple[1])) # tuple
        print("PYTHON: 4.1 : ", len(image_tuple[1])) # of length as #images passed of same person ...
        print("PYTHON: 5.1 : ", type(image_tuple[1][0]), len(image_tuple[1][0])) # tuple of length 2 having metadata for first image 
        print("PYTHON: 6.1 : ", type(image_tuple[1][0][0])) # tuple of length 4 -> label, width, height, depth 
        print("PYTHON: 6.2 : ", len(image_tuple[1][0][0])) # tuple of length 4 -> label, width, height, depth 
        print("PYTHON: 7.1 : ", type(image_tuple[1][0][1])) # tuple        
        print("PYTHON: 7.2 : ", len(image_tuple[1][0][1])) # image data as 1D array ...
    

    
    # # output is is this structure
    # (
    #     ReturnCode->int,
    #     long-data-1D-tuple->[double],
    #     (
    #         #1st face's eye details
    #         (isLeftAssigned->int(0 or 1), isRightAssigned->int(0 or 1), xleft->int, yleft->int, xright->int, yright->int),
    #         ...
    #         ...
    #         ...
    #         #Nth face's eye details
    #         (isLeftAssigned->int(0 or 1), isRightAssigned->int(0 or 1), xleft->int, yleft->int, xright->int, yright->int)
    #     )
    # )
    return (
        0, # return code -> frvt_structs.h  
        tuple([0.0012]*64), #  MUST HAVE (999,999,999)
        (
            (1, 0, 1, 1, 2, 2), # isLeftAssigned,isRightAssigned,xleft, y_left, x_right, y_right   EyePair (frvt_structs.h)
        )*len(image_tuple[1]),
    )

def create_template_single_images_mutiple_faces(image_tuple):
    DEBUG = False
    # # input is is this structure
    # (
    #     TemplateRole->int,
    #     (
    #         (#1st face details
    #             (label->int, width->int, height->int, depth->int),
    #             (long-data-1D-list->[int])
    #         ),
    #         ...
    #         ...
    #         ...
    #         (#Nth face details
    #             (label->int, width->int, height->int, depth->int),
    #             (long-data-1D-list->[int])
    #         )
    #     )
    # )
    if DEBUG:
        print('create_template_single_images_mutiple_faces => input info ...')
        print('10.1', type(image_tuple)) # tuple
        print('10.2', len(image_tuple)) # of length 2
        print('11.1', type(image_tuple[0])) # int
        print('11.2', image_tuple[0]) # with TemplateRole
        print('12.1', type(image_tuple[1])) # tuple 
        print('12.2', len(image_tuple[1])) # of length 1(always) 
        print('13.1', type(image_tuple[1][0])) # tuple
        print('13.2', len(image_tuple[1][0])) # of length 2, 0th for meta, 1st for iamge-data
        print('14.1', image_tuple[1][0][0]) # tuple of length 4 having meta -> label,width,height,depth
        print('14.2', type(image_tuple[1][0][1])) # tuple
        print('14.3', len(image_tuple[1][0][1])) # of length of image-data (w*h*(depth/8))
        
    # # output is is this structure
    # (
    #     ReturnCode->int,
    #     (
    #         (long-data-1D-tuple->[double]),
    #         (long-data-1D-tuple->[double]),
    #         ...
    #         ...
    #         ... n templates for n face detected ...
    #         (long-data-1D-tuple->[double])
    #     ),
    #     (
    #         #1st face's eye details
    #         (isLeftAssigned->int(0 or 1), isRightAssigned->int(0 or 1), xleft->int, yleft->int, xright->int, yright->int),
    #         ...
    #         ...
    #         ...
    #         #Nth face's eye details
    #         (isLeftAssigned->int(0 or 1), isRightAssigned->int(0 or 1), xleft->int, yleft->int, xright->int, yright->int),
    #     )
    # )
    num_face_detected = 3
    return (
        0,
        (tuple([0.0012]*64),)*num_face_detected,
        (
            (1, 0, 1, 1, 2, 2),
        )*num_face_detected,
    )





