"""Test the binding of names when a circular import shares the same name as an
attribute."""
from .rebinding2 import util
